# -*- coding: utf-8 -*-
"""清洗 CSV：去掉空行、去重、输出统计。"""

import csv
import sys


def clean(rows):
    seen = set()
    out = []
    for row in rows:
        key = tuple(row)
        if not any(row) or key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def main(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    rows = clean(rows)
    print(f"有效行数: {len(rows)}")
    for row in rows[:10]:
        print(" | ".join(row))


if __name__ == "__main__":
    main(sys.argv[1])
