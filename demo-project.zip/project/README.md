# 待注释的项目

这是一个用于测试 CodeNotes 导入功能的小项目。

## 结构

- src/     前端模块
- python/  数据处理脚本
- config/  配置
- docs/    文档
