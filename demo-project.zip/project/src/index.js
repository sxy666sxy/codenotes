import { createStore } from './core/store.js';
import { render } from './core/view.js';

const store = createStore({ todos: [] });

store.subscribe((state) => {
  render(document.querySelector('#app'), state);
});

document.querySelector('#add').addEventListener('click', () => {
  const input = document.querySelector('#input');
  if (!input.value.trim()) return;
  store.dispatch({ type: 'ADD_TODO', text: input.value.trim() });
  input.value = '';
});
