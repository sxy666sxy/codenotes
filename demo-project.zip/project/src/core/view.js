export function render(root, state) {
  root.innerHTML = `
    <ul>
      ${state.todos.map((t) => `<li>${escapeHtml(t.text)}</li>`).join('')}
    </ul>
  `;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}
