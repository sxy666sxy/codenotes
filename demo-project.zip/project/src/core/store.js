/**
 * 极简状态容器：状态只读，修改必须通过 dispatch。
 */
export function createStore(initial) {
  let state = initial;
  const listeners = new Set();

  return {
    getState: () => state,
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    dispatch(action) {
      state = reduce(state, action);
      listeners.forEach((fn) => fn(state));
    },
  };
}

function reduce(state, action) {
  switch (action.type) {
    case 'ADD_TODO':
      return { ...state, todos: [...state.todos, { text: action.text, done: false }] };
    default:
      return state;
  }
}
